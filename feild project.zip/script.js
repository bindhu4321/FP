// LOGIN
function login() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email === "" || password === "") {
        alert("Enter details");
        return;
    }

    window.location.href = "details.html";
}

// SUBMIT DETAILS
function goToSubmit() {
    let name = document.querySelector("input[placeholder='Name']").value;
    let phone = document.querySelector("input[placeholder='Phone']").value;
    let email = document.querySelector("input[placeholder='Email']").value;
    let house = document.querySelector("input[placeholder='House Number']").value;
    let qty = document.getElementById("qty").value;
    let type = document.getElementById("type").value;

    if (!name || !phone || !email || !house || !qty || !type) {
        alert("Please fill all fields");
        return;
    }

    let report = { name, phone, email, house, qty, type };

    // Get existing reports
    let reports = JSON.parse(localStorage.getItem("reports")) || [];

    // Add new report
    reports.push(report);

    // Save back
    localStorage.setItem("reports", JSON.stringify(reports));

    window.location.href = "submit.html";
}

// GO TO DECOMPOSE PAGE
function goToDecompose() {
    window.location.href = "decompose.html";
}

// SHOW ALL REPORTS
window.onload = function () {
    let container = document.getElementById("allReports");

    if (!container) return;

    let reports = JSON.parse(localStorage.getItem("reports")) || [];

    if (reports.length === 0) {
        container.innerHTML = "<p>No reports found</p>";
        return;
    }

    reports.forEach((r, index) => {

        let method = "";
        let time = "";
        let impact = "";

        if (r.type === "organic") {
            method = "Composting using microorganisms.";
            time = "2–6 weeks";
            impact = "Creates fertilizer 🌱";
        } 
        else if (r.type === "plastic") {
            method = "Recycling process.";
            time = "100–500 years if not recycled!";
            impact = "Reduces pollution ♻️";
        } 
        else if (r.type === "ewaste") {
            method = "Special e-waste recycling.";
            time = "Several years";
            impact = "Prevents toxins ⚠️";
        }

        container.innerHTML += `
            <div style="border:1px solid #ccc; margin:10px; padding:10px; border-radius:10px;">
                <h3>Report ${index + 1}</h3>
                <p><b>Name:</b> ${r.name}</p>
                <p><b>Phone:</b> ${r.phone}</p>
                <p><b>House:</b> ${r.house}</p>
                <p><b>Quantity:</b> ${r.qty} kg</p>
                <p><b>Type:</b> ${r.type}</p>

                <h4>♻️ Decomposition</h4>
                <p>Method: ${method}</p>
                <p>Time: ${time}</p>
                <p>Impact: ${impact}</p>
            </div>
        `;
    });
};